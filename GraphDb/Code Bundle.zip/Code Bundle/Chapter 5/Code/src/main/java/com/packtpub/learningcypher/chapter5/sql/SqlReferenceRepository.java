/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */
package com.packtpub.learningcypher.chapter5.sql;

import com.packtpub.learningcypher.chapter5.model.*;
import java.sql.*;
import java.util.*;
import java.util.logging.*;
import org.neo4j.helpers.Pair;

/**
 * Implementation of a {@code ReferenceRepository} using SQL
 *
 * @author Onofrio Panzarino
 */
public class SqlReferenceRepository implements ReferenceRepository, AutoCloseable {

    private final Connection connection;

    public SqlReferenceRepository(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Reference byId(int id) {
        try (PreparedStatement statement = connection.prepareStatement("SELECT * FROM REFERENCEENTRIES WHERE Id = ?")) {
            statement.setInt(1, id);
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    return loadFrom(result);
                }
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(SqlReferenceRepository.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public Reference loadFrom(ResultSet result) throws SQLException {
        int id = result.getInt("id");
        String title = result.getString("title");
        String abstr = result.getString("abstractText");
        return new Reference(id, title, abstr);
    }

    public Author loadAuthor(ResultSet result) throws SQLException {
        int id = result.getInt("id");
        String name = result.getString("name");
        String surname = result.getString("surname");
        return new Author(id, name, surname);
    }

    public Set<Reference> citedIn(Reference work) {
        Set<Reference> ret = new TreeSet<>(Reference.IdComparator);
        if (work.getId() == -1) {
            return ret;
        }

        try (PreparedStatement statement = connection
                .prepareStatement("SELECT REFERENCEENTRIES.* FROM REFERENCEENTRIES JOIN ReferenceCitations ON ReferenceCitations.CitationId = ?")) {

            statement.setInt(1, work.getId());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    ret.add(loadFrom(result));
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(SqlReferenceRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ret;
    }

    public Set<Author> getAuthors() {
        try (PreparedStatement statement = connection.prepareStatement(
                "select ID, NAME, SURNAME from AUTHORS order by ID")) {
            Set<Author> ret = new HashSet<>();
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    ret.add(loadAuthor(result));
                }
            }
            return ret;
        } catch (SQLException ex) {
            Logger.getLogger(SqlReferenceRepository.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public Set<Reference> getAll() {
        try (PreparedStatement statement = connection.prepareStatement("select ID, TITLE, ABSTRACTTEXT from REFERENCEENTRIES")) {
            Set<Reference> ret = new TreeSet<>(Reference.IdComparator);
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    ret.add(loadFrom(result));
                }
            }
            return ret;
        } catch (SQLException ex) {
            Logger.getLogger(SqlReferenceRepository.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public Set<Reference> findByTitle(String title) {
        try (PreparedStatement statement = connection.prepareStatement("select * from REFERENCEENTRIES where title like ?")) {
            statement.setString(1, "%" + title + "%");

            Set<Reference> ret = new TreeSet<>(Reference.IdComparator);
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    ret.add(loadFrom(result));
                }
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(SqlReferenceRepository.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public void save(Reference reference) {
    }

    @Override
    public List<Author> getAuthors(Reference entry) {
        try (PreparedStatement statement = connection.prepareStatement(
                "select ID, NAME, SURNAME from AUTHORS join ReferenceAuthors on ReferenceAuthors.AuthorId = Authors.Id where ReferenceId = ? order by SortOrder")) {
            statement.setInt(1, entry.getId());

            List<Author> ret = new LinkedList<>();
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    ret.add(loadAuthor(result));
                }
            }
            return ret;
        } catch (SQLException ex) {
            Logger.getLogger(SqlReferenceRepository.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public Set<Reference> getCitedReferences(Reference entry) {
        return citedIn(entry);
    }

    @Override
    public void save(Author author) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setTags(Reference reference, Set<String> tags) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Set<String> getTags(Reference reference) {
        try (PreparedStatement statement = connection.prepareStatement("select TAG from EntryTags where ReferenceId = ?")) {
            statement.setInt(1, reference.getId());

            Set<String> ret = new TreeSet<>();
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    ret.add(result.getString("Tag"));
                }
            }
            return ret;
        } catch (SQLException ex) {
            Logger.getLogger(SqlReferenceRepository.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public void setPublisherOf(Reference r, Publisher p, int year) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Pair<Publisher, Integer> getPublisherOf(Reference reference) {
        try (PreparedStatement statement = connection.prepareStatement("select PublishedYear, PublishedBy from ReferenceEntries where ID = ?")) {
            statement.setInt(1, reference.getId());

            final Set<String> ret = new TreeSet<>();
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    String name = result.getString("PublishedBy");
                    int year = result.getInt("PublishedYear");
                    return Pair.of(new Publisher(name), new Integer(year));
                }
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(SqlReferenceRepository.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public Set<Publisher> getPublishers() {
        try (PreparedStatement statement = connection.prepareStatement("select Name from Publishers")) {

            final Set<Publisher> ret = new HashSet<>();
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    String name = result.getString("Name");
                    ret.add(new Publisher(name));
                }
            }
            return ret;
        } catch (SQLException ex) {
            Logger.getLogger(SqlReferenceRepository.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public void save(Publisher publisher) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Set<Reference> findByTag(String tag) {
        try (PreparedStatement statement = connection
                .prepareStatement(
                        "select ReferenceEntries.* from EntryTags join ReferenceEntries on ReferenceEntries.ID = EntryTags.ReferenceId where Tag = ?")) {
                    statement.setString(1, tag);

                    Set<Reference> ret = new TreeSet<>(Reference.IdComparator);
                    try (ResultSet result = statement.executeQuery()) {
                        while (result.next()) {
                            ret.add(loadFrom(result));
                        }
                    }
                    return null;
                } catch (SQLException ex) {
                    Logger.getLogger(SqlReferenceRepository.class.getName()).log(Level.SEVERE, null, ex);
                    return null;
                }
    }

    @Override
    public void close() throws SQLException {
        this.connection.close();
    }

    @Override
    public void delete(Author author) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void cites(Reference entry, Set<Reference> cited) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void dumpQuery(String query) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(query)) {

            ResultSet rs = statement.executeQuery();
            System.out.println(rs);

        }
    }

    public void mostCitedReferences() throws SQLException {
        dumpQuery("select Id, CNT \n"
                + " from (\n"
                + "select ReferenceEntries.Id,\n"
                + "       Count(ReferenceCitations.ReferenceId) as CNT\n"
                + "  from EntryTags \n"
                + "  join ReferenceEntries \n"
                + "    on ReferenceEntries.ID = EntryTags.ReferenceId \n"
                + "  join ReferenceCitations\n"
                + "    on ReferenceCitations.CitationId = ReferenceEntries.Id\n"
                + " where Tag = 'Neo4j'\n"
                + " group by ReferenceEntries.Id  \n"
                + ") refQ\n"
                + " order by refQ.CNT desc");
    }

    public void mostCitedAuthors() throws SQLException {
        dumpQuery("select AuthorId, CNT \n"
                + " from (\n"
                + "select ReferenceAuthors.AuthorId,\n"
                + "       Count(ReferenceCitations.ReferenceId) as CNT\n"
                + "  from EntryTags \n"
                + "  join ReferenceEntries \n"
                + "    on ReferenceEntries.ID = EntryTags.ReferenceId \n"
                + "  join ReferenceCitations\n"
                + "    on ReferenceCitations.CitationId = ReferenceEntries.Id\n"
                + "  join ReferenceAuthors\n"
                + "    on ReferenceAuthors.ReferenceId = ReferenceEntries.Id\n"
                + "group by ReferenceAuthors.AuthorId\n"
                + ") refQ\n"
                + " order by refQ.CNT desc");
    }
}
