package com.packtpub.learningcypher.chapter5;

import com.packtpub.learningcypher.chapter5.cypher.*;
import com.packtpub.learningcypher.chapter5.sql.*;
import java.util.logging.*;

/**
 * This program perform a migration of data, schema and queries of a SQL
 * database
 */
public class App {

    public static void main(String[] args) {

        try (CypherReferenceRepository neoRepo = new Neo4jDatabaseSetup().setup()) {
            try (SqlReferenceRepository sqlRepo = new SqlDatabaseSetup().setup()) {
                sqlRepo.mostCitedReferences();
                sqlRepo.mostCitedAuthors();

                System.out.println("Migrating schema...");
                MigrateSchema migrateSchema = new MigrateSchema(neoRepo);
                migrateSchema.createIndexes();
                migrateSchema.createConstraints();

                System.out.println("Migrating data...");
                MigrateData migrateData = new MigrateData(sqlRepo, neoRepo);
                System.out.println("Migrating authors...");
                migrateData.migrateAuthors();
                System.out.println("Migrating publisher...");
                migrateData.migratePublishers();
                System.out.println("Migrating references...");
                migrateData.migrateReferences();

                System.out.println("Testing queries: 1");
                neoRepo.mostCitedReferences();
                System.out.println("Testing queries: 2");
                neoRepo.mostCitedAuthors();
            }
        } catch (Exception ex) {
            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
