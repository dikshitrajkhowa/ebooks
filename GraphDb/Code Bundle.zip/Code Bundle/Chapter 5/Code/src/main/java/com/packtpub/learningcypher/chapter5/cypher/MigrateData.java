/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

package com.packtpub.learningcypher.chapter5.cypher;

import com.packtpub.learningcypher.chapter5.model.*;
import com.packtpub.learningcypher.chapter5.sql.SqlReferenceRepository;
import java.util.*;
import org.neo4j.helpers.Pair;

/**
 * This class is responsible to migrate data
 * 
 * @author Onofrio Panzarino
 */
public class MigrateData {
    private final SqlReferenceRepository sqlRepo;
    private final CypherReferenceRepository cypherRepo;

    public MigrateData(SqlReferenceRepository sqlRepo, CypherReferenceRepository cypherRepo) {
        this.sqlRepo = sqlRepo;
        this.cypherRepo = cypherRepo;
    }
  
    public void migrateAuthors() {
        Set<Author> authors = sqlRepo.getAuthors();
        for(Author a : authors) {
            cypherRepo.save(a);
        }
    }
    
    public void migratePublishers() {
        Set<Publisher> publisher = sqlRepo.getPublishers();
        for(Publisher p: publisher) {
            cypherRepo.save(p);
        }
    }
    
    public void migrateReferences() {
        Set<Reference> refer = sqlRepo.getAll();
        
        for(Reference r : refer) {
            cypherRepo.save(r);
            cypherRepo.setTags(r, sqlRepo.getTags(r));
            
            Pair<Publisher,Integer> publisher = sqlRepo.getPublisherOf(r);
            cypherRepo.setPublisherOf(r, publisher.first(), publisher.other().intValue());
            
            List<Author> authors = sqlRepo.getAuthors(r);
            cypherRepo.setAuthors(r, authors);
            
            Set<Reference> cited = sqlRepo.getCitedReferences(r);
            cypherRepo.cites(r, cited);
        }
    }
}
