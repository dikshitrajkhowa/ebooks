package com.packtpub.learningcypher.chapter5.model;

import java.util.Comparator;

/**
 * A Reference entry
 * 
 * @author Onofrio Panzarino
 */
public class Reference {
    private final int id;
    private final String title, abstractText;
    
    public Reference(int id, String title, String abstractText) {
        this.id = id;
        this.title = title;
        this.abstractText = abstractText;
    }
    
    public int getId() { return id; }

    public String getTitle() { return title; }

    public String getAbstractText() { return abstractText; }
    
    /**
     * Comparator by ID
     */
    public static final Comparator<Reference> IdComparator = new  Comparator<Reference>() {
        @Override
        public int compare(Reference o1, Reference o2) {
            return o1.getId() - o2.getId();
        }
    };
}
