/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */
package com.packtpub.learningcypher.chapter5.cypher;

import org.neo4j.cypher.javacompat.ExecutionEngine;

/**
 * This class migrate the schema of the database
 * 
 * @author Onofrio Panzarino
 */
public class MigrateSchema {

    private final ExecutionEngine engine;

    public MigrateSchema(ExecutionEngine engine) {
        this.engine = engine;
    }
    
    public MigrateSchema(CypherReferenceRepository repo) {
        this.engine = repo.engine;
    }

    public void createConstraints() {
        engine.execute("CREATE CONSTRAINT ON (r:Reference) \n"
                + "ASSERT r.id IS UNIQUE");
        
        engine.execute("CREATE CONSTRAINT ON (r:Author) \n" +
"ASSERT r.id IS UNIQUE");
        
        engine.execute("CREATE CONSTRAINT ON (r:Publisher) \n" +
"ASSERT r.name IS UNIQUE");
    }
    
    public void createIndexes() {
        engine.execute("CREATE INDEX ON :Reference(title)");
        engine.execute("CREATE INDEX ON :Reference(tags)");
        engine.execute("CREATE INDEX ON :Author(surname)");
    }
}
