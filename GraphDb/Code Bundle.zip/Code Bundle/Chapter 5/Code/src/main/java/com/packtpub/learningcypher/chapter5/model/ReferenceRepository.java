/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */
package com.packtpub.learningcypher.chapter5.model;

import java.util.*;

/**
 * Interface of a repository.
 * 
 * @author Onofrio Panzarino
 */
public interface ReferenceRepository {

    public Reference byId(int id);

    public Set<Reference> findByTitle(String title);
    
    public Set<Reference> findByTag(String tag);

    public void delete(Author author);
    
    public void save(Reference reference);

    public void save(Author author);
    
    public void save(Publisher publisher);

    public Set<String> getTags(Reference reference);

    public void setTags(Reference reference, Set<String> tags);

    public List<Author> getAuthors(Reference entry);

    public Set<Reference> getCitedReferences(Reference entry);

    public void setPublisherOf(Reference r, Publisher p, int year);

    public Set<Publisher> getPublishers();
    
    public void cites(Reference entry, Set<Reference> cited);
}
