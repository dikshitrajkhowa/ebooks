/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */
package com.packtpub.learningcypher.chapter5.cypher;

import org.neo4j.cypher.javacompat.ExecutionEngine;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;

/**
 * This class is to setup a new embedded database.
 *
 * @author Onofrio Panzarino
 */
public class Neo4jDatabaseSetup {

    private static final String DB_PATH = "database/biblio";

    private GraphDatabaseService create() {
        GraphDatabaseFactory graphDbFactory = new GraphDatabaseFactory();
        GraphDatabaseService db = graphDbFactory.newEmbeddedDatabase(DB_PATH);
        return db;
    }

    public CypherReferenceRepository setup() {
        GraphDatabaseService db = create();
        return setup(db);
    }
    
    public CypherReferenceRepository setup(GraphDatabaseService db) {
        return new CypherReferenceRepository(new ExecutionEngine(db), db);
    }
}
