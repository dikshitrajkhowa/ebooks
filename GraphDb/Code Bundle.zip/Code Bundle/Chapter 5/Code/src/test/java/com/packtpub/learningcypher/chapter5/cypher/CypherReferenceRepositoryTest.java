/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

package com.packtpub.learningcypher.chapter5.cypher;

import com.packtpub.learningcypher.chapter5.model.Author;
import com.packtpub.learningcypher.chapter5.model.CitedStats;
import com.packtpub.learningcypher.chapter5.model.Publisher;
import com.packtpub.learningcypher.chapter5.model.Reference;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import junit.framework.TestCase;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.test.ImpermanentGraphDatabase;

/**
 *
 * @author Onofrio Panzarino <onofrio.panzarino@gmail.com>
 */
public class CypherReferenceRepositoryTest extends TestCase {
    
    public CypherReferenceRepositoryTest(String testName) {
        super(testName);
    }

    private CypherReferenceRepository db;
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        
        db = new Neo4jDatabaseSetup().setup(new ImpermanentGraphDatabase("database/biblio"));
        final Reference lr = new Reference(12, "Learning Cypher", "Design and create flexible and fast graph databases using the Cypher declarative syntax");
        db.save(lr);
        
        List<Author> authors = new LinkedList<>();
        authors.add(new Author(4, "Onofrio", "Panzarino"));
        db.setAuthors(lr, authors);
        
        db.setPublisherOf(lr, new Publisher("Packt Publishing"), 2014);
        
        final Reference refCard = new Reference(1, "Neo4j Cypher Refcard 2.0", "Neo4j Cypher Refcard 2.0");
        db.save(refCard);
        db.setAuthor(refCard, new Author(44, "", "Neo Technology"));
        
        final Set<Reference> cited = new HashSet<>();
        cited.add(refCard);
        db.cites(lr, cited);
    }
    
    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testFindByTitle() {
        Set<Reference> found = db.findByTitle("Learning");
        assertEquals(found.size(), 1);
        for(Reference r : found) {
            assertEquals(12, r.getId());
            assertEquals("Learning Cypher", r.getTitle());
        }
    }
    
    public void testMostCitedReferences() {
        Iterator<CitedStats<Reference>> references = db.mostCitedReferences();
        while(references.hasNext()) {
            CitedStats<Reference> r = references.next();
            assertEquals(1, r.getCitations());
        }
        assertFalse(references.hasNext());
    }
    
    public void testMostCitedAuthors() {
        Iterator<CitedStats<Author>> authors = db.mostCitedAuthors();
        while(authors.hasNext()) {
            CitedStats<Author> a = authors.next();
            assertEquals(1, a.getCitations());
        }
        assertFalse(authors.hasNext());
    }
}
