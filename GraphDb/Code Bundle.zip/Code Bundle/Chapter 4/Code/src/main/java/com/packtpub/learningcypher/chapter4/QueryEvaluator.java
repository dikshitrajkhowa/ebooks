package com.packtpub.learningcypher.chapter4;

import org.neo4j.cypher.javacompat.*;

/**
 * Prints the execution plan of a query
 * 
 * @author Onofrio Panzarino
 */
public class QueryEvaluator {

    private String query;

    public QueryEvaluator() {
    }

    public void evaluating(String query) {
        this.query = query;
    }

    public void done(ExecutionResult res) {
        System.out.print("Query: ");
        System.out.println(query);

        // Needed before calling executionPlanDescription
        res.dumpToString();

        PlanDescription planDescription = res.executionPlanDescription();
        System.out.println("Execution plan: ");
        System.out.println(planDescription.toString());
        System.out.println();
    }

    public void reset() {
        this.query = null;
    }

    public void finish() {
        reset();
    }
}
