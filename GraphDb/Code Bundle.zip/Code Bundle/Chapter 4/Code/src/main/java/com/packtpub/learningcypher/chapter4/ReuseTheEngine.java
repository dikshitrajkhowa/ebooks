package com.packtpub.learningcypher.chapter4;

import java.util.HashMap;
import java.util.Map;
import org.neo4j.cypher.javacompat.ExecutionEngine;
import org.neo4j.cypher.javacompat.ExecutionResult;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.ResourceIterator;

/**
 * Practices related to reusing the engine
 * 
 * @author Onofrio Panzarino
 */
public class ReuseTheEngine {
    private final GraphDatabaseService graphDatabaseService;
    private final ExecutionEngine engine;

    public ReuseTheEngine(GraphDatabaseService graphDatabaseService, ExecutionEngine engine) {
        this.graphDatabaseService = graphDatabaseService;
        this.engine = engine;
    }
    
    public ResourceIterator<Node> find(String email) {
        Map<String,Object> map = new HashMap<>();
        map.put("email", email);
        ExecutionResult result = engine.execute("MATCH(n:User {email: {email} }) RETURN n", map);
        
        return result.columnAs("n");
    }
    
    /**
     * Don't create an ExecutionEngine for each query!
     * 
     * @param email 
     * @return the seto of node found 
     */
    @Deprecated()
    public ResourceIterator<Node> dontWriteFunctionsLikeThis(String email) {
        ExecutionEngine engine = new ExecutionEngine(graphDatabaseService);
        
        Map<String,Object> map = new HashMap<>();
        map.put("email", email);
        ExecutionResult result = engine.execute("MATCH(n:User {email: {email} }) RETURN n", map);
        
        return result.columnAs("n");
    }
    
    
}
