/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

package com.packtpub.learningcypher.chapter4;

/**
 * Evaluator of time duration.
 * 
 * @author Onofrio Panzarino
 */
public class TimeEvaluator {
    private long startTime;
    private String task;
    
    public void start(String task) {
        startTime = System.nanoTime();
        this.task = task;
    }
    
    public long end() {
        long endTime = System.nanoTime();
        
        long duration = endTime - startTime;
        System.out.println(task);
        System.out.print("duration: ");
        System.out.print(duration / 1000000.0);
        System.out.println(" ms");
        
        return duration;
    }
}
