package com.packtpub.learningcypher.chapter4;

import org.neo4j.cypher.javacompat.ExecutionEngine;
import org.neo4j.graphdb.GraphDatabaseService;

/**
 * Entry point
 * 
 * Let's create the database, run the benchmarks and profile them
 *
 * @author Onofrio Panzarino
 */
public class App 
{
    public static void main( String[] args )
    {
        DatabaseSetup ds = new DatabaseSetup();
        ds.clearAll();
        
        GraphDatabaseService db = ds.create();
        try {
            ds.setup(db);
            ExecutionEngine engine = new ExecutionEngine(db);
            
            SchemaIndexes si = new SchemaIndexes(engine, db);
            
            Benchmark b = new Benchmark(db);
            b.setEvaluator(new QueryEvaluator());
            b.evaluateFindNode();
            
            si.addLabelIndex();
            b.evaluateFindNode();
            
            si.addConstraint();
            b.evaluateFindInactiveUsers();
            
            b.evaluateFindInactiveUsersUsingScanHint();
 
            TimeEvaluator ev = new TimeEvaluator();
            ev.start("MATCH(n:User {email: '\" + email + \"'}) RETURN n");
            LoopBenchmark.createFinderNoParameters(new ExecutionEngine(db))
                    .run();
            ev.end();
            
            ev.start("MATCH(n:User {email: {emailQuery}}) RETURN n");
            LoopBenchmark.createFinderWithParameters(new ExecutionEngine(db))
                    .run();
            ev.end();
            
            ev.start("Group count average - naive");
            LoopBenchmark.createAvgCalculatorNonOptimized(new ExecutionEngine(db))
                    .run();
            ev.end();
            
            ev.start("Group count average - optimized");
            LoopBenchmark.createAvgCalculatorOptimized(new ExecutionEngine(db))
                    .run();
            ev.end();
        }
        finally {
            db.shutdown();
        }
    }
}
