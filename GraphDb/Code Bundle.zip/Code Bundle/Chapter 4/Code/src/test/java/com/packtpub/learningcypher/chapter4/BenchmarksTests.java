/*
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

package com.packtpub.learningcypher.chapter4;

import junit.framework.TestCase;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.test.TestGraphDatabaseFactory;

/**
 * @author Onofrio Panzarino
 */
public class BenchmarksTests extends TestCase {
    
    public BenchmarksTests(String testName) {
        super(testName);
    }
   
    private GraphDatabaseService graphDb;
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        graphDb = new TestGraphDatabaseFactory().newImpermanentDatabase();
        
        DatabaseSetup initializer = new DatabaseSetup();
        initializer.setup(graphDb);
    }
    
    @Override
    protected void tearDown() throws Exception {
        
        graphDb.shutdown();
        super.tearDown();
        graphDb = null;
    }    
}
