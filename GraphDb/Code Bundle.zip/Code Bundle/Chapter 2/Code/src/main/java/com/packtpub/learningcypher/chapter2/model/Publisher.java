package com.packtpub.learningcypher.chapter2.model;

/**
 * A publisher
 * @author Onofrio Panzarino
 */
public interface Publisher {
    String getName();
    
    void setName(String name);
}
