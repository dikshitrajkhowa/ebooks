package com.packtpub.learningcypher.chapter2.model;

/**
 * A person
 * 
 * @author Onofrio Panzarino
 */
public interface Person {

    String getName();

    String getSurname();

    void setName(String name);

    void setSurname(String surname);
    
}
